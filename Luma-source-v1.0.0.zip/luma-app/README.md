# Luma for Android TV and Fire TV

Luma is an independent Android TV / Fire TV IPTV player with a dark, cinematic interface, top search, horizontal channel rows, a TV guide, and categories for Live TV, Sports, Movies, Series, Downloads, and Favourites.

## Playlist support

- M3U playlist address over HTTPS.
- Xtream-compatible server address, username, and password over HTTPS. Luma uses the common `player_api.php` live, movies, series, and series episode actions.
- Optional XMLTV guide address. With Xtream, Luma tries the provider's standard `xmltv.php` endpoint when no guide address is entered.
- Live playback through AndroidX Media3, including HLS and DASH.

Compatibility depends on the provider. Providers that use a modified API, HTTP-only endpoints, DRM, extra authentication headers, or unsupported stream formats may not work. Luma does not contain channel lists, credentials, stream URLs, provider branding, or catalogue artwork. Add only playlists and streams you are authorized to access. Xtream compatibility is not guaranteed for every provider; modified APIs, HTTP-only endpoints, DRM, extra headers, and unsupported stream formats are not supported.

Playlist addresses and login details are encrypted with an Android Keystore key and stored only on the device. The app disables Android backup and cleartext HTTP traffic. Removing the app also removes the saved playlist configuration.

## License

Luma source is licensed under GNU GPL version 3 or later; see `COPYING`.

## Build

Open this folder in Android Studio and let Gradle sync. The project uses Android SDK 37 and supports Android API 23 and later. To create a debug APK from a terminal, run `./gradlew assembleDebug` in this folder.
