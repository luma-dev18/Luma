// SPDX-License-Identifier: GPL-3.0-or-later

package app.luma.tv

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayOutputStream
import java.io.StringReader
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.net.ssl.HttpsURLConnection

internal data class PlaylistConfig(
    val name: String,
    val sourceType: String,
    val url: String,
    val username: String,
    val password: String,
    val epgUrl: String
)

internal data class TvChannel(
    val id: String,
    val name: String,
    val group: String,
    val logoUrl: String,
    val streamUrl: String,
    val kind: String = "live",
    val description: String = "",
    val guideId: String = ""
)

internal data class Programme(val title: String, val startsAt: Long, val endsAt: Long)
internal data class SeriesEpisode(val id: String, val title: String, val season: String, val streamUrl: String)
internal data class LoadedPlaylist(
    val channels: List<TvChannel>,
    val movies: List<TvChannel>,
    val series: List<TvChannel>,
    val guide: Map<String, List<Programme>>
)

internal object PlaylistLoader {
    suspend fun fetch(url: String): String = withContext(Dispatchers.IO) {
        fetchHttps(url)
    }

    fun parseM3u(text: String): List<TvChannel> {
        val channels = mutableListOf<TvChannel>()
        var title: String? = null
        var group = "Other"
        var logo = ""
        var tvgId = ""

        text.lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val comma = line.indexOf(',')
                    title = if (comma >= 0) line.substring(comma + 1).trim().ifBlank { "Channel" } else "Channel"
                    group = attribute(line, "group-title").ifBlank { "Other" }
                    logo = attribute(line, "tvg-logo")
                    tvgId = attribute(line, "tvg-id")
                }
                line.isNotEmpty() && !line.startsWith('#') && title != null -> {
                    val stream = runCatching { URL(line) }.getOrNull()
                    if (stream?.protocol.equals("https", ignoreCase = true) && !stream?.host.isNullOrBlank()) {
                        val safeTitle = title.orEmpty()
                        val kind = when {
                            group.contains("series", true) || group.contains("episode", true) -> "episode"
                            group.contains("movie", true) || group.contains("vod", true) -> "movie"
                            else -> "live"
                        }
                        channels += TvChannel(
                            id = "${tvgId.ifBlank { safeTitle.lowercase(Locale.ROOT) }}-${channels.size}",
                            name = safeTitle,
                            group = group,
                            logoUrl = logo,
                            streamUrl = stream.toString(),
                            kind = kind,
                            guideId = tvgId
                        )
                    }
                    title = null
                    group = "Other"
                    logo = ""
                    tvgId = ""
                }
            }
        }
        require(channels.isNotEmpty()) { "This playlist has no usable HTTPS channels." }
        return channels
    }

    suspend fun load(config: PlaylistConfig): LoadedPlaylist {
        val channels: List<TvChannel>
        val movies: List<TvChannel>
        val series: List<TvChannel>
        if (config.sourceType == SOURCE_XTREAM) {
            channels = loadXtreamChannels(config)
            movies = runCatching { loadXtreamMovies(config) }.getOrDefault(emptyList())
            series = runCatching { loadXtreamSeries(config) }.getOrDefault(emptyList())
        } else {
            val m3uChannels = parseM3u(fetch(config.url))
            channels = m3uChannels.filter { it.kind == "live" }
            movies = m3uChannels.filter { it.kind == "movie" }
            series = m3uChannels.filter { it.kind == "episode" }
        }
        val guideAddress = if (config.epgUrl.isNotBlank()) config.epgUrl else if (config.sourceType == SOURCE_XTREAM) xtreamUrl(config, "xmltv.php") else ""
        val guide = if (guideAddress.isBlank()) emptyMap() else runCatching {
            parseXmltv(fetch(guideAddress))
        }.getOrDefault(emptyMap())
        return LoadedPlaylist(channels, movies, series, guide)
    }

    private suspend fun loadXtreamChannels(config: PlaylistConfig): List<TvChannel> {
        require(config.username.isNotBlank() && config.password.isNotBlank()) { "Enter your Xtream username and password." }
        val account = JSONObject(fetch(xtreamUrl(config, "player_api.php")))
        require(account.optJSONObject("user_info")?.optInt("auth", 0) == 1) {
            "The provider did not accept these login details. Check the address and account details."
        }
        val categoriesJson = JSONArray(fetch(xtreamUrl(config, "player_api.php", "get_live_categories")))
        val categories = buildMap<String, String> {
            for (i in 0 until categoriesJson.length()) {
                val item = categoriesJson.optJSONObject(i) ?: continue
                put(item.optString("category_id"), item.optString("category_name", "Other"))
            }
        }
        val streamsJson = JSONArray(fetch(xtreamUrl(config, "player_api.php", "get_live_streams")))
        val channels = buildList {
            for (i in 0 until streamsJson.length()) {
                val item = streamsJson.optJSONObject(i) ?: continue
                val streamId = item.optString("stream_id")
                val extension = item.optString("container_extension").ifBlank { "ts" }
                val streamUrl = xtreamUrl(config, "live/${config.username}/${config.password}/$streamId.$extension")
                if (streamId.isBlank() || runCatching { URL(streamUrl).protocol == "https" }.getOrDefault(false).not()) continue
                add(
                    TvChannel(
                        id = "live-$streamId",
                        name = item.optString("name").ifBlank { "Channel $streamId" },
                        group = categories[item.optString("category_id")].orEmpty().ifBlank { "Other" },
                        logoUrl = item.optString("stream_icon"),
                        streamUrl = streamUrl,
                        guideId = item.optString("epg_channel_id")
                    )
                )
            }
        }
        require(channels.isNotEmpty()) { "The provider returned no usable HTTPS live channels." }
        return channels
    }

    private suspend fun loadXtreamMovies(config: PlaylistConfig): List<TvChannel> {
        val categoriesJson = JSONArray(fetch(xtreamUrl(config, "player_api.php", "get_vod_categories")))
        val categories = buildMap<String, String> {
            for (i in 0 until categoriesJson.length()) {
                val item = categoriesJson.optJSONObject(i) ?: continue
                put(item.optString("category_id"), item.optString("category_name", "Movies"))
            }
        }
        val streamsJson = JSONArray(fetch(xtreamUrl(config, "player_api.php", "get_vod_streams")))
        return buildList {
            for (i in 0 until streamsJson.length()) {
                val item = streamsJson.optJSONObject(i) ?: continue
                val id = item.optString("stream_id")
                val ext = item.optString("container_extension").ifBlank { "mp4" }
                if (id.isBlank()) continue
                val streamUrl = xtreamUrl(config, "movie/${config.username}/${config.password}/$id.$ext")
                if (!isHttps(streamUrl)) continue
                add(TvChannel("movie-$id", item.optString("name").ifBlank { "Movie $id" }, categories[item.optString("category_id")].orEmpty().ifBlank { "Movies" }, item.optString("stream_icon"), streamUrl, "movie", item.optString("plot")))
            }
        }
    }

    private suspend fun loadXtreamSeries(config: PlaylistConfig): List<TvChannel> {
        val categoriesJson = JSONArray(fetch(xtreamUrl(config, "player_api.php", "get_series_categories")))
        val categories = buildMap<String, String> {
            for (i in 0 until categoriesJson.length()) {
                val item = categoriesJson.optJSONObject(i) ?: continue
                put(item.optString("category_id"), item.optString("category_name", "Series"))
            }
        }
        val seriesJson = JSONArray(fetch(xtreamUrl(config, "player_api.php", "get_series")))
        return buildList {
            for (i in 0 until seriesJson.length()) {
                val item = seriesJson.optJSONObject(i) ?: continue
                val id = item.optString("series_id")
                if (id.isBlank()) continue
                add(TvChannel(id, item.optString("name").ifBlank { "Series $id" }, categories[item.optString("category_id")].orEmpty().ifBlank { "Series" }, item.optString("cover"), "", "series", item.optString("plot")))
            }
        }
    }

    suspend fun loadSeriesEpisodes(config: PlaylistConfig, seriesId: String): List<SeriesEpisode> {
        val response = JSONObject(fetch(xtreamUrl(config, "player_api.php", "get_series_info", mapOf("series_id" to seriesId))))
        val seasons = response.optJSONObject("episodes") ?: return emptyList()
        return buildList {
            val keys = seasons.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }
            for (season in keys) {
                val episodes = seasons.optJSONArray(season) ?: continue
                for (i in 0 until episodes.length()) {
                    val item = episodes.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    if (id.isBlank()) continue
                    val ext = item.optString("container_extension").ifBlank { "mp4" }
                    val stream = xtreamUrl(config, "series/${config.username}/${config.password}/$id.$ext")
                    if (isHttps(stream)) add(SeriesEpisode(id, item.optString("title").ifBlank { "Episode ${i + 1}" }, season, stream))
                }
            }
        }
    }

    private fun isHttps(address: String): Boolean = runCatching {
        URL(address).let { it.protocol.equals("https", true) && it.host.isNotBlank() }
    }.getOrDefault(false)

    private fun xtreamUrl(config: PlaylistConfig, path: String, action: String? = null, extra: Map<String, String> = emptyMap()): String {
        val base = runCatching { android.net.Uri.parse(config.url.trim()) }.getOrNull()
            ?: throw IllegalArgumentException("Enter a valid Xtream server address.")
        require(base.scheme.equals("https", ignoreCase = true) && !base.host.isNullOrBlank()) {
            "For your security, Xtream server addresses must use HTTPS."
        }
        val builder = base.buildUpon()
        path.split('/').filter { it.isNotBlank() }.forEach(builder::appendPath)
        if (path == "player_api.php" || path == "xmltv.php") {
            builder.appendQueryParameter("username", config.username)
                .appendQueryParameter("password", config.password)
        }
        if (action != null) builder.appendQueryParameter("action", action)
        extra.forEach { (key, value) -> builder.appendQueryParameter(key, value) }
        return builder.build().toString()
    }

    fun parseXmltv(xml: String, now: Long = System.currentTimeMillis()): Map<String, List<Programme>> {
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = false
        val parser = factory.newPullParser()
        parser.setInput(StringReader(xml))
        val byChannel = mutableMapOf<String, MutableList<Programme>>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "programme") {
                val channel = parser.getAttributeValue(null, "channel").orEmpty()
                val start = parseXmltvTime(parser.getAttributeValue(null, "start"))
                val end = parseXmltvTime(parser.getAttributeValue(null, "stop"))
                var title = ""
                var nested = parser.next()
                while (!(nested == XmlPullParser.END_TAG && parser.name == "programme") && nested != XmlPullParser.END_DOCUMENT) {
                    if (nested == XmlPullParser.START_TAG && parser.name == "title") {
                        title = parser.nextText().trim()
                    } else {
                        nested = parser.next()
                        continue
                    }
                    nested = parser.eventType
                }
                if (channel.isNotBlank() && title.isNotBlank() && start != null && end != null && end > now) {
                    byChannel.getOrPut(channel) { mutableListOf() } += Programme(title, start, end)
                }
            }
            event = parser.next()
        }
        return byChannel.mapValues { (_, programmes) ->
            programmes.sortedBy { it.startsAt }.take(2)
        }
    }

    private fun parseXmltvTime(raw: String?): Long? {
        if (raw.isNullOrBlank()) return null
        val match = Regex("^(\\d{14})(?:\\s+([+-]\\d{4}))?.*$").matchEntire(raw.trim()) ?: return null
        val zone = match.groupValues[2].ifBlank { "+0000" }
        val format = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US).apply { isLenient = false }
        return runCatching { format.parse("${match.groupValues[1]} $zone")?.time }.getOrNull()
    }

    private fun attribute(line: String, name: String): String {
        val escaped = Regex.escape(name)
        return Regex("(?:^|\\s)$escaped=\"([^\"]*)\"", RegexOption.IGNORE_CASE)
            .find(line)?.groupValues?.getOrNull(1).orEmpty()
    }

    private fun fetchHttps(rawUrl: String): String {
        require(rawUrl.length <= 4096) { "The playlist address is too long." }
        var address = runCatching { URL(rawUrl.trim()) }.getOrNull()
            ?: throw IllegalArgumentException("Enter a valid HTTPS playlist address.")
        require(address.protocol.equals("https", ignoreCase = true) && address.host.isNotBlank()) {
            "For your security, playlist and guide addresses must use HTTPS."
        }

        repeat(5) {
            val connection = address.openConnection() as? HttpsURLConnection
                ?: throw IllegalArgumentException("Only HTTPS playlist addresses are supported.")
            try {
                connection.connectTimeout = 15_000
                connection.readTimeout = 20_000
                connection.instanceFollowRedirects = false
                connection.setRequestProperty("Accept", "application/x-mpegURL, application/vnd.apple.mpegurl, application/xml, text/xml, text/plain, */*")
                val status = connection.responseCode
                if (status in 300..399) {
                    val location = connection.getHeaderField("Location")
                        ?: throw IllegalArgumentException("The playlist address redirected unexpectedly.")
                    address = URL(address, location)
                    require(address.protocol.equals("https", ignoreCase = true)) {
                        "The playlist server redirected to an insecure address."
                    }
                    return@repeat
                }
                require(status in 200..299) { "The playlist server could not be reached (HTTP $status)." }
                val output = ByteArrayOutputStream()
                connection.inputStream.use { input ->
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_RESPONSE_BYTES) { "The playlist is larger than Luma can import." }
                        output.write(buffer, 0, count)
                    }
                }
                return output.toString(Charsets.UTF_8.name())
            } finally {
                connection.disconnect()
            }
        }
        throw IllegalArgumentException("The playlist server redirected too many times.")
    }

    private const val MAX_RESPONSE_BYTES = 8 * 1024 * 1024
}

internal object PlaylistStore {
    private const val PREFS = "luma_private_playlist"
    private const val VALUE = "encrypted_config"
    private const val KEY_ALIAS = "luma_playlist_encryption_key"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun save(context: Context, config: PlaylistConfig) {
        val json = JSONObject()
            .put("name", config.name)
            .put("sourceType", config.sourceType)
            .put("url", config.url)
            .put("username", config.username)
            .put("password", config.password)
            .put("epg", config.epgUrl)
            .toString()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getKey())
        val encrypted = cipher.doFinal(json.toByteArray(Charsets.UTF_8))
        val value = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(VALUE, value).apply()
    }

    fun load(context: Context): PlaylistConfig? = runCatching {
        val value = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(VALUE, null) ?: return null
        val parts = value.split(':', limit = 2)
        require(parts.size == 2)
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getKey(), GCMParameterSpec(128, iv))
        val json = JSONObject(String(cipher.doFinal(encrypted), Charsets.UTF_8))
        PlaylistConfig(
            json.getString("name"), json.optString("sourceType", SOURCE_M3U), json.getString("url"),
            json.optString("username"), json.optString("password"), json.optString("epg")
        )
    }.getOrNull()

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(VALUE).apply()
    }

    private fun getKey(): SecretKey {
        val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }
}

internal const val SOURCE_M3U = "m3u"
internal const val SOURCE_XTREAM = "xtream"
