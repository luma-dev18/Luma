// SPDX-License-Identifier: GPL-3.0-or-later

package app.luma.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LumaApp() }
    }
}

private val Night = Color(0xFF090A10)
private val SurfaceDark = Color(0xFF14151F)
private val Lilac = Color(0xFFB994FF)
private val SoftWhite = Color(0xFFF5F2FA)
private val Muted = Color(0xFFAAA8B6)
private val categories = listOf("Home", "Live TV", "TV Guide", "Sports", "Movies", "Series", "Downloads", "Favourites")

@Composable
private fun LumaApp() {
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("home") }
    var selectedCategory by remember { mutableStateOf("Home") }
    var config by remember { mutableStateOf<PlaylistConfig?>(null) }
    var channels by remember { mutableStateOf<List<TvChannel>>(emptyList()) }
    var movies by remember { mutableStateOf<List<TvChannel>>(emptyList()) }
    var series by remember { mutableStateOf<List<TvChannel>>(emptyList()) }
    var guide by remember { mutableStateOf<Map<String, List<Programme>>>(emptyMap()) }
    var activeChannel by remember { mutableStateOf<TvChannel?>(null) }
    var activeSeries by remember { mutableStateOf<TvChannel?>(null) }
    var seriesEpisodes by remember { mutableStateOf<List<SeriesEpisode>>(emptyList()) }
    var seriesLoading by remember { mutableStateOf(false) }
    var playerReturnPage by remember { mutableStateOf("home") }
    var loading by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var favourites by remember { mutableStateOf(setOf<String>()) }

    val loadPlaylist: (PlaylistConfig, Boolean) -> Unit = { candidate, saveAfterLoad ->
        scope.launch {
            loading = true
            feedback = "Connecting to playlist…"
            try {
                val result = PlaylistLoader.load(candidate)
                if (saveAfterLoad) PlaylistStore.save(context, candidate)
                config = candidate
                channels = result.channels
                movies = result.movies
                series = result.series
                guide = result.guide
                page = "home"
                selectedCategory = "Home"
                feedback = if (result.guide.isEmpty()) {
                    "${result.channels.size} channels loaded. No TV guide data was found."
                } else {
                    "${result.channels.size} channels and TV guide loaded."
                }
            } catch (error: Exception) {
                feedback = if (error is IllegalArgumentException) error.message.orEmpty()
                    else "Luma could not load this playlist. Check the address, account details, and provider compatibility."
                if (feedback.isBlank()) feedback = "Luma could not load this playlist. Check the address and provider compatibility."
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        val saved = PlaylistStore.load(context)
        if (saved != null) loadPlaylist(saved, false)
    }

    BackHandler(enabled = page != "home") {
        if (page == "player") page = "home" else page = "home"
    }

    MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme(
        primary = Lilac,
        onPrimary = Night,
        background = Night,
        surface = SurfaceDark,
        onSurface = SoftWhite
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            when (page) {
                "setup" -> PlaylistSetup(
                    existing = config,
                    loading = loading,
                    message = feedback,
                    onCancel = { page = "home" },
                    onSave = { loadPlaylist(it, true) },
                    onRemove = {
                        PlaylistStore.clear(context)
                        config = null
                        channels = emptyList()
                        movies = emptyList()
                        series = emptyList()
                        guide = emptyMap()
                        feedback = "Playlist removed from this device."
                        page = "home"
                    }
                )
                "player" -> activeChannel?.let { channel ->
                    PlaybackScreen(channel = channel, onBack = { page = playerReturnPage })
                } ?: CategoryEmpty("Live TV")
                "series" -> activeSeries?.let { item ->
                    SeriesDetailScreen(item, seriesEpisodes, seriesLoading, feedback, onBack = { page = "home" }, onPlay = { episode ->
                        activeChannel = TvChannel(episode.id, episode.title, "Season ${episode.season}", item.logoUrl, episode.streamUrl, "episode")
                        playerReturnPage = "series"
                        page = "player"
                    })
                } ?: CategoryEmpty("Series")
                else -> HomeScreen(
                    nav = categories,
                    selected = selectedCategory,
                    onSelect = { selectedCategory = it },
                    channels = channels,
                    movies = movies,
                    series = series,
                    guide = guide,
                    playlistName = config?.name.orEmpty(),
                    message = feedback,
                    searchOpen = searchOpen,
                    search = search,
                    onSearchToggle = { searchOpen = !searchOpen; if (!searchOpen) search = "" },
                    onSearchChange = { search = it },
                    onAddPlaylist = { page = "setup" },
                    favourites = favourites,
                    onToggleFavourite = { id -> favourites = if (id in favourites) favourites - id else favourites + id },
                    onPlay = { channel -> activeChannel = channel; playerReturnPage = "home"; page = "player" },
                    onOpenSeries = { item ->
                        activeSeries = item
                        seriesEpisodes = emptyList()
                        seriesLoading = true
                        feedback = "Loading episodes…"
                        page = "series"
                        val currentConfig = config
                        if (currentConfig == null) {
                            seriesLoading = false
                            feedback = "Connect an Xtream-compatible playlist to open series."
                        } else {
                            scope.launch {
                                try {
                                    seriesEpisodes = PlaylistLoader.loadSeriesEpisodes(currentConfig, item.id)
                                    feedback = if (seriesEpisodes.isEmpty()) "No episodes were returned for this series." else ""
                                } catch (_: Exception) {
                                    feedback = "Episodes could not be loaded. The provider may not support the standard series API."
                                } finally {
                                    seriesLoading = false
                                }
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    nav: List<String>, selected: String, onSelect: (String) -> Unit,
    channels: List<TvChannel>, movies: List<TvChannel>, series: List<TvChannel>, guide: Map<String, List<Programme>>, playlistName: String,
    message: String, searchOpen: Boolean, search: String,
    onSearchToggle: () -> Unit, onSearchChange: (String) -> Unit,
    onAddPlaylist: () -> Unit, favourites: Set<String>, onToggleFavourite: (String) -> Unit,
    onPlay: (TvChannel) -> Unit, onOpenSeries: (TvChannel) -> Unit
) {
    val matching = if (search.isBlank()) channels else channels.filter { it.name.contains(search, true) || it.group.contains(search, true) }
    val matchingMovies = if (search.isBlank()) movies else movies.filter { it.name.contains(search, true) || it.group.contains(search, true) }
    val matchingSeries = if (search.isBlank()) series else series.filter { it.name.contains(search, true) || it.group.contains(search, true) }
    val groups = matching.map { it.group }.distinct()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Header(nav, selected, onSelect, searchOpen, onSearchToggle, search, onSearchChange, playlistName, onAddPlaylist)
        }
        if (selected == "Home") {
            item { Hero(playlistName = playlistName, channel = matching.firstOrNull(), onAddPlaylist = onAddPlaylist, onPlay = onPlay) }
            if (matching.isNotEmpty()) {
                item { ChannelRow("Live TV", "On now", matching, guide, favourites, onToggleFavourite, onPlay) }
                item { GuideRow(matching, guide, onPlay) }
                groups.filter { it.contains("sport", true) }.forEach { group ->
                    item { ChannelRow(group, "From $playlistName", matching.filter { it.group == group }, guide, favourites, onToggleFavourite, onPlay) }
                }
            } else if (matchingMovies.isEmpty() && matchingSeries.isEmpty()) {
                item { EmptyLibrary(playlistName, onAddPlaylist) }
            }
            if (matchingMovies.isNotEmpty()) item { ChannelRow("Movies", "From your playlist", matchingMovies, emptyMap(), favourites, onToggleFavourite, onPlay, tall = true) }
            if (matchingSeries.isNotEmpty()) item { ChannelRow("Series", "From your playlist", matchingSeries, emptyMap(), favourites, onToggleFavourite, onPlay, tall = true, onOpenSeries = onOpenSeries) }
        } else when (selected) {
            "Live TV" -> if (matching.isEmpty()) item { EmptyLibrary(playlistName, onAddPlaylist) }
                else item { ChannelRow("Live TV", "${matching.size} channels", matching, guide, favourites, onToggleFavourite, onPlay, tall = true) }
            "TV Guide" -> if (matching.isEmpty() || guide.isEmpty()) item { GuideEmpty(onAddPlaylist) }
                else item { GuidePage(matching, guide, onPlay) }
            "Sports" -> {
                val matches = matching.filter { it.group.contains("sport", true) }
                if (matches.isEmpty()) item { CategoryEmpty(selected) }
                else item { ChannelRow(selected, "${matches.size} channels", matches, guide, favourites, onToggleFavourite, onPlay, tall = true) }
            }
            "Movies" -> if (matchingMovies.isEmpty()) item { CategoryEmpty("Movies") }
                else item { ChannelRow("Movies", "${matchingMovies.size} titles", matchingMovies, emptyMap(), favourites, onToggleFavourite, onPlay, tall = true) }
            "Series" -> if (matchingSeries.isEmpty()) item { CategoryEmpty("Series") }
                else item { ChannelRow("Series", "${matchingSeries.size} shows", matchingSeries, emptyMap(), favourites, onToggleFavourite, onPlay, tall = true, onOpenSeries = onOpenSeries) }
            "Downloads" -> item { CategoryEmpty("Downloads") }
            "Favourites" -> {
                val saved = (matching + matchingMovies + matchingSeries).filter { it.id in favourites }
                if (saved.isEmpty()) item { CategoryEmpty("Favourites") }
                else item { ChannelRow("Favourites", "${saved.size} saved", saved, guide, favourites, onToggleFavourite, onPlay, tall = true, onOpenSeries = onOpenSeries) }
            }
        }
    }
}

@Composable
private fun Header(
    nav: List<String>, selected: String, onSelect: (String) -> Unit,
    searchOpen: Boolean, onSearchToggle: () -> Unit, search: String, onSearchChange: (String) -> Unit,
    playlistName: String, onAddPlaylist: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 52.dp, end = 52.dp, top = 26.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 30.dp)) {
            LumaMark(34)
            Spacer(Modifier.width(10.dp))
            Text("LUMA", color = SoftWhite, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        }
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(1.dp), verticalAlignment = Alignment.CenterVertically) {
            nav.forEach { label ->
                var focused by remember { mutableStateOf(false) }
                Text(
                    label,
                    color = if (label == selected) SoftWhite else Muted,
                    fontSize = 13.sp,
                    fontWeight = if (label == selected) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(18.dp))
                        .background(if (focused) Color(0xFF292438) else Color.Transparent)
                        .clickable { onSelect(label) }.onFocusChanged { focused = it.isFocused }.focusable()
                        .padding(horizontal = 9.dp, vertical = 10.dp)
                )
            }
        }
        if (searchOpen) {
            BasicTextField(
                value = search, onValueChange = onSearchChange, singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = SoftWhite, fontSize = 14.sp),
                modifier = Modifier.width(155.dp).clip(RoundedCornerShape(20.dp)).background(SurfaceDark).padding(horizontal = 13.dp, vertical = 11.dp),
                decorationBox = { inner -> Box { if (search.isEmpty()) Text("Search channels", color = Muted, fontSize = 13.sp); inner() } }
            )
        } else {
            HeaderPill("⌕  Search", onSearchToggle)
        }
        Spacer(Modifier.width(8.dp))
        HeaderPill(if (playlistName.isBlank()) "+ Playlist" else playlistName, onAddPlaylist)
        Spacer(Modifier.width(14.dp))
        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF292438)), contentAlignment = Alignment.Center) {
            Text("L", color = Lilac, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HeaderPill(label: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(label, color = SoftWhite, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.widthIn(max = 150.dp).clip(RoundedCornerShape(20.dp))
            .background(if (focused) Color(0xFF292438) else SurfaceDark)
            .clickable { onClick() }.onFocusChanged { focused = it.isFocused }.focusable()
            .padding(horizontal = 12.dp, vertical = 10.dp))
}

@Composable
private fun LumaMark(size: Int) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFF211B31)), contentAlignment = Alignment.Center) {
        Text("L", color = Lilac, fontSize = (size * .68f).sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun Hero(playlistName: String, channel: TvChannel?, onAddPlaylist: () -> Unit, onPlay: (TvChannel) -> Unit) {
    Box(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 40.dp).height(330.dp).clip(RoundedCornerShape(22.dp))
            .drawWithCache {
                val brush = Brush.linearGradient(listOf(Color(0xFF2D5472), Color(0xFF4A315A), Color(0xFF171522)), start = Offset.Zero, end = Offset(size.width, size.height))
                onDrawBehind {
                    drawRect(brush)
                    drawCircle(Color(0x33E3B3FF), radius = size.height * .82f, center = Offset(size.width * .78f, size.height * .12f))
                    drawCircle(Color(0x337DBDE3), radius = size.height * .6f, center = Offset(size.width * .82f, size.height * .3f))
                    drawRect(Brush.horizontalGradient(listOf(Color(0xEE090A10), Color(0xAA090A10), Color.Transparent), startX = 0f, endX = size.width * .75f))
                    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x88090A10)), startY = size.height * .48f, endY = size.height))
                }
            }
    ) {
        Column(Modifier.align(Alignment.CenterStart).padding(start = 48.dp, end = 24.dp).width(550.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LumaMark(22)
                Spacer(Modifier.width(9.dp))
                Text(if (channel != null) "LIVE ON LUMA" else "YOUR TV, YOUR WAY", color = Color(0xFFE5D8FF), fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
            Text(channel?.name ?: "A BRIGHTER\nWAY TO WATCH", color = SoftWhite, fontSize = 43.sp, lineHeight = 47.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
            Text(if (channel != null) "${channel.group}  ·  ${playlistName.ifBlank { "Your playlist" }}" else "Bring together the channels you are authorized to watch.", color = Color(0xFFE2DDE9), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ActionButton(if (channel != null) "▶   Watch live" else "+   Add playlist", true) {
                    if (channel != null) onPlay(channel) else onAddPlaylist()
                }
            }
        }
        Text("LUMA  ·  LIVE TV", color = Color(0xFFD6CBE4), fontSize = 11.sp, letterSpacing = 1.3.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp))
    }
}

@Composable
private fun ActionButton(label: String, primary: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(label, color = if (primary) Night else SoftWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (primary) Lilac else Color(0x66363540))
            .then(if (focused) Modifier.border(2.dp, SoftWhite, RoundedCornerShape(8.dp)) else Modifier)
            .clickable { onClick() }.onFocusChanged { focused = it.isFocused }.focusable()
            .padding(horizontal = 20.dp, vertical = 12.dp))
}

@Composable
private fun ChannelRow(
    title: String, subtitle: String, channels: List<TvChannel>, guide: Map<String, List<Programme>>,
    favourites: Set<String>, onToggleFavourite: (String) -> Unit, onPlay: (TvChannel) -> Unit, tall: Boolean = false,
    onOpenSeries: ((TvChannel) -> Unit)? = null
) {
    Column {
        Row(Modifier.fillMaxWidth().padding(start = 48.dp, end = 48.dp, bottom = 10.dp), verticalAlignment = Alignment.Bottom) {
            Text(title, color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Text(subtitle, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 2.dp))
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 48.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(channels, key = { "${it.kind}-${it.id}" }) { channel ->
                ChannelCard(channel, guide[channel.guideId.ifBlank { channel.id }].orEmpty().firstOrNull(), favourites, tall, onToggleFavourite, onPlay, onOpenSeries)
            }
        }
    }
}

@Composable
private fun ChannelCard(
    channel: TvChannel, programme: Programme?, favourites: Set<String>, tall: Boolean,
    onToggleFavourite: (String) -> Unit, onPlay: (TvChannel) -> Unit, onOpenSeries: ((TvChannel) -> Unit)?
) {
    var focused by remember { mutableStateOf(false) }
    Column(Modifier.width(if (tall) 250.dp else 230.dp)) {
        Box(
            Modifier.fillMaxWidth().height(if (tall) 150.dp else 128.dp).clip(RoundedCornerShape(12.dp))
                .clickable { if (channel.kind == "series") onOpenSeries?.invoke(channel) else onPlay(channel) }
                .onFocusChanged { focused = it.isFocused }.focusable()
                .then(if (focused) Modifier.border(3.dp, Lilac, RoundedCornerShape(12.dp)) else Modifier)
                .background(Brush.linearGradient(listOf(colorFor(channel.group), Color(0xFF171522)), Offset.Zero, Offset(600f, 400f)))
        ) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC090A10)), startY = 30f)))
            Text("LIVE", color = SoftWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFE8434F)).padding(horizontal = 7.dp, vertical = 5.dp))
            Text(if (channel.logoUrl.isNotBlank()) "◉" else channel.name.take(1).uppercase(), color = Color(0x66F5F2FA), fontSize = 46.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.Center))
            Text(channel.name.uppercase(), color = SoftWhite, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(start = 13.dp, bottom = 12.dp, end = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(channel.name, color = if (focused) SoftWhite else Color(0xFFE0DDE6), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 2.dp, top = 7.dp))
        Text(programme?.title ?: channel.group, color = Muted, fontSize = 11.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 2.dp, top = 2.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            MiniAction(if (channel.kind == "series") "Details" else "▶ Watch") {
                if (channel.kind == "series") onOpenSeries?.invoke(channel) else onPlay(channel)
            }
            MiniAction(if (channel.id in favourites) "♥ Saved" else "＋ Save") { onToggleFavourite(channel.id) }
        }
    }
}

@Composable
private fun MiniAction(label: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(label, color = if (focused) Night else Lilac, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(6.dp))
            .background(if (focused) Lilac else Color(0x332C2539)).clickable { onClick() }
            .onFocusChanged { focused = it.isFocused }.focusable().padding(horizontal = 9.dp, vertical = 6.dp))
}

@Composable
private fun GuideRow(channels: List<TvChannel>, guide: Map<String, List<Programme>>, onPlay: (TvChannel) -> Unit) {
    val withGuide = channels.filter { guide[it.guideId.ifBlank { it.id }].orEmpty().isNotEmpty() }
    Column {
        Row(Modifier.fillMaxWidth().padding(start = 48.dp, end = 48.dp, bottom = 10.dp), verticalAlignment = Alignment.Bottom) {
            Text("TV Guide", color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Text("What's on now and next", color = Muted, fontSize = 13.sp)
        }
        if (withGuide.isEmpty()) {
            Text("Guide information appears when your playlist includes matching TV guide data.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 48.dp))
        } else {
            LazyRow(contentPadding = PaddingValues(horizontal = 48.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(withGuide.take(8), key = { "guide-${it.id}" }) { channel ->
                    val shows = guide[channel.guideId.ifBlank { channel.id }].orEmpty()
                    GuideCard(channel, shows, onPlay)
                }
            }
        }
    }
}

@Composable
private fun GuideCard(channel: TvChannel, shows: List<Programme>, onPlay: (TvChannel) -> Unit) {
    Column(Modifier.width(260.dp).clip(RoundedCornerShape(12.dp)).background(SurfaceDark).padding(14.dp)) {
        Text(channel.name, color = SoftWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        shows.take(2).forEachIndexed { index, show ->
            Spacer(Modifier.height(10.dp))
            Text(if (index == 0) "NOW" else "NEXT", color = Lilac, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(show.title, color = SoftWhite, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${clock(show.startsAt)} – ${clock(show.endsAt)}", color = Muted, fontSize = 10.sp)
        }
        MiniAction("▶ Watch channel") { onPlay(channel) }
    }
}

@Composable
private fun GuidePage(channels: List<TvChannel>, guide: Map<String, List<Programme>>, onPlay: (TvChannel) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 48.dp)) {
        Text("TV Guide", color = SoftWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        channels.filter { guide[it.guideId.ifBlank { it.id }].orEmpty().isNotEmpty() }.forEach { channel ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(channel.name, color = SoftWhite, fontWeight = FontWeight.Bold, modifier = Modifier.width(220.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                guide[channel.guideId.ifBlank { channel.id }].orEmpty().take(2).forEach { program ->
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceDark).padding(12.dp)) {
                        Text("${clock(program.startsAt)}  ·  ${clock(program.endsAt)}", color = Lilac, fontSize = 11.sp)
                        Text(program.title, color = SoftWhite, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                MiniAction("▶") { onPlay(channel) }
            }
        }
    }
}

@Composable
private fun EmptyLibrary(playlistName: String, onAddPlaylist: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 48.dp).clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(28.dp)) {
        Text(if (playlistName.isBlank()) "Add your playlist to get started" else "No channels are available right now", color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Connect an M3U playlist or an Xtream-compatible service you are authorized to use.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))
        ActionButton("+   Add playlist", true, onAddPlaylist)
    }
}

@Composable
private fun GuideEmpty(onAddPlaylist: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 48.dp).clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(28.dp)) {
        Text("TV guide data isn't available", color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Add an XMLTV guide address in playlist settings, or use a compatible Xtream provider that supplies one.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))
        ActionButton("Playlist settings", true, onAddPlaylist)
    }
}

@Composable
private fun CategoryEmpty(category: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 48.dp).clip(RoundedCornerShape(18.dp)).background(SurfaceDark).padding(28.dp)) {
        Text("Nothing in $category yet", color = SoftWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Luma shows the channels supplied by your playlist. This category will fill when your provider supplies matching groups.", color = Muted, fontSize = 14.sp)
    }
}

@Composable
private fun PlaylistSetup(
    existing: PlaylistConfig?, loading: Boolean, message: String,
    onCancel: () -> Unit, onSave: (PlaylistConfig) -> Unit, onRemove: () -> Unit
) {
    var sourceType by remember(existing) { mutableStateOf(existing?.sourceType ?: SOURCE_M3U) }
    var name by remember(existing) { mutableStateOf(existing?.name ?: "My Playlist") }
    var address by remember(existing) { mutableStateOf(existing?.url.orEmpty()) }
    var username by remember(existing) { mutableStateOf(existing?.username.orEmpty()) }
    var password by remember(existing) { mutableStateOf(existing?.password.orEmpty()) }
    var epg by remember(existing) { mutableStateOf(existing?.epgUrl.orEmpty()) }
    var authorized by remember(existing) { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Night).padding(start = 72.dp, end = 72.dp, top = 30.dp, bottom = 30.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Playlist setup", color = SoftWhite, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onCancel) { Text("Back", color = Lilac) }
        }
        Spacer(Modifier.height(5.dp))
        Text("Connect a compatible service. Playlist addresses and login details are encrypted on this device.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SourceChip("M3U playlist", sourceType == SOURCE_M3U) { sourceType = SOURCE_M3U }
            SourceChip("Xtream login", sourceType == SOURCE_XTREAM) { sourceType = SOURCE_XTREAM }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            SetupField("Playlist name", name, { name = it }, Modifier.weight(1f))
            SetupField(if (sourceType == SOURCE_M3U) "M3U HTTPS address" else "Xtream server HTTPS address", address, { address = it }, Modifier.weight(2f))
        }
        if (sourceType == SOURCE_XTREAM) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SetupField("Username", username, { username = it }, Modifier.weight(1f))
                SetupField("Password", password, { password = it }, Modifier.weight(1f), secret = true)
            }
        }
        Spacer(Modifier.height(12.dp))
        SetupField("XMLTV guide HTTPS address (optional)", epg, { epg = it }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { authorized = !authorized }.focusable()) {
            Checkbox(checked = authorized, onCheckedChange = { authorized = it })
            Text("I am authorized to access and watch the content in this playlist.", color = SoftWhite, fontSize = 13.sp)
        }
        Text("Xtream support uses the provider's standard live-channel API. Some providers require a different API, DRM, or extra headers and may not work here.", color = Muted, fontSize = 12.sp)
        if (message.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(message, color = if (message.startsWith("Connecting")) Lilac else Color(0xFFFFB7B7), fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                enabled = !loading && authorized && name.isNotBlank() && address.isNotBlank() && (sourceType != SOURCE_XTREAM || (username.isNotBlank() && password.isNotBlank())),
                onClick = {
                    onSave(PlaylistConfig(name.trim(), sourceType, address.trim(), username, password, epg.trim()))
                },
                colors = ButtonDefaults.buttonColors(containerColor = Lilac, contentColor = Night)
            ) { Text(if (loading) "Connecting…" else "Connect playlist", fontWeight = FontWeight.Bold) }
            if (existing != null) TextButton(onClick = onRemove) { Text("Remove playlist", color = Color(0xFFFFA3A3)) }
        }
    }
}

@Composable
private fun SourceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(label, color = if (selected) Night else SoftWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(if (selected || focused) Lilac else SurfaceDark)
            .clickable { onClick() }.onFocusChanged { focused = it.isFocused }.focusable().padding(horizontal = 18.dp, vertical = 11.dp))
}

@Composable
private fun SetupField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier, secret: Boolean = false) {
    Column(modifier) {
        Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            singleLine = true,
            visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            textStyle = androidx.compose.ui.text.TextStyle(color = SoftWhite, fontSize = 14.sp),
            shape = RoundedCornerShape(9.dp)
        )
    }
}

@Composable
private fun SeriesDetailScreen(
    series: TvChannel, episodes: List<SeriesEpisode>, loading: Boolean, message: String,
    onBack: () -> Unit, onPlay: (SeriesEpisode) -> Unit
) {
    Column(Modifier.fillMaxSize().background(Night).padding(start = 56.dp, end = 56.dp, top = 28.dp, bottom = 28.dp)) {
        TextButton(onClick = onBack) { Text("‹  Back to Luma", color = Lilac) }
        Spacer(Modifier.height(8.dp))
        Text(series.name, color = SoftWhite, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(series.group, color = Muted, fontSize = 14.sp)
        if (series.description.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(series.description, color = Color(0xFFD7D3DF), fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(20.dp))
        Text(if (loading) "Loading episodes…" else "Episodes", color = SoftWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (message.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(message, color = if (loading) Lilac else Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(episodes, key = { it.id }) { episode ->
                var focused by remember { mutableStateOf(false) }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp))
                        .background(if (focused) Color(0xFF292438) else SurfaceDark)
                        .clickable { onPlay(episode) }.onFocusChanged { focused = it.isFocused }.focusable()
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("S${episode.season}", color = Lilac, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(60.dp))
                    Text(episode.title, color = SoftWhite, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("▶ Play", color = Lilac, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PlaybackScreen(channel: TvChannel, onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var playbackError by remember { mutableStateOf("") }
    val player = remember(channel.streamUrl) {
        ExoPlayer.Builder(context).build().also { exo ->
            val item = MediaItem.Builder().setUri(channel.streamUrl).apply {
                if (channel.streamUrl.substringBefore('?').endsWith(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8)
                if (channel.streamUrl.substringBefore('?').endsWith(".mpd", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_MPD)
            }.build()
            exo.setMediaItem(item)
            exo.prepare()
            exo.playWhenReady = true
        }
    }
    DisposableEffect(player, lifecycleOwner) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                playbackError = "This stream could not be played. The provider may use an unsupported format or access method."
            }
        }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> player.play()
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> player.pause()
                else -> Unit
            }
        }
        player.addListener(listener)
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.removeListener(listener)
            player.release()
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { viewContext -> PlayerView(viewContext).apply {
                this.player = player
                useController = true
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                keepScreenOn = true
            } },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize()
        )
        Column(Modifier.align(Alignment.TopStart).padding(28.dp)) {
            TextButton(onClick = onBack) { Text("‹  Back to Luma", color = SoftWhite) }
            Text(channel.name, color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
            if (playbackError.isNotBlank()) Text(playbackError, color = Color(0xFFFFB7B7), fontSize = 13.sp, modifier = Modifier.padding(start = 12.dp, top = 8.dp))
        }
    }
}

private fun colorFor(group: String): Color = when {
    group.contains("sport", true) -> Color(0xFF1D624E)
    group.contains("news", true) -> Color(0xFF20435B)
    group.contains("movie", true) -> Color(0xFF653D61)
    group.contains("kids", true) -> Color(0xFF637044)
    else -> Color(0xFF594A8A)
}

private fun clock(time: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
